[@elizaos/core v0.1.7-alpha.1](../index.md) / CacheStore

# Enumeration: CacheStore

## Enumeration Members

### REDIS

> **REDIS**: `"redis"`

#### Defined in

[packages/core/src/types.ts:1011](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1011)

***

### DATABASE

> **DATABASE**: `"database"`

#### Defined in

[packages/core/src/types.ts:1012](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1012)

***

### FILESYSTEM

> **FILESYSTEM**: `"filesystem"`

#### Defined in

[packages/core/src/types.ts:1013](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1013)

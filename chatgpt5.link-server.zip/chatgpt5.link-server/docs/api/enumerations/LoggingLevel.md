[@elizaos/core v0.1.7-alpha.1](../index.md) / LoggingLevel

# Enumeration: LoggingLevel

## Enumeration Members

### DEBUG

> **DEBUG**: `"debug"`

#### Defined in

[packages/core/src/types.ts:1240](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1240)

***

### VERBOSE

> **VERBOSE**: `"verbose"`

#### Defined in

[packages/core/src/types.ts:1241](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1241)

***

### NONE

> **NONE**: `"none"`

#### Defined in

[packages/core/src/types.ts:1242](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1242)

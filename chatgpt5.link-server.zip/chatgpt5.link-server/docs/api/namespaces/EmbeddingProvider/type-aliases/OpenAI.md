[@elizaos/core v0.1.7-alpha.1](../../../index.md) / [EmbeddingProvider](../index.md) / OpenAI

# Type Alias: OpenAI

> **OpenAI**: *typeof* `EmbeddingProvider.OpenAI`

## Defined in

[packages/core/src/embedding.ts:28](https://github.com/elizaOS/eliza/blob/main/packages/core/src/embedding.ts#L28)

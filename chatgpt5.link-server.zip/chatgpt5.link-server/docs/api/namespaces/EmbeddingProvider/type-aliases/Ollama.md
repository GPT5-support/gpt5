[@elizaos/core v0.1.7-alpha.1](../../../index.md) / [EmbeddingProvider](../index.md) / Ollama

# Type Alias: Ollama

> **Ollama**: *typeof* `EmbeddingProvider.Ollama`

## Defined in

[packages/core/src/embedding.ts:29](https://github.com/elizaOS/eliza/blob/main/packages/core/src/embedding.ts#L29)

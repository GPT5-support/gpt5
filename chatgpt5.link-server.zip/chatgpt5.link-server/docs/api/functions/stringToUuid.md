[@elizaos/core v0.1.7-alpha.1](../index.md) / stringToUuid

# Function: stringToUuid()

> **stringToUuid**(`target`): [`UUID`](../type-aliases/UUID.md)

## Parameters

• **target**: `string` \| `number`

## Returns

[`UUID`](../type-aliases/UUID.md)

## Defined in

[packages/core/src/uuid.ts:4](https://github.com/elizaOS/eliza/blob/main/packages/core/src/uuid.ts#L4)

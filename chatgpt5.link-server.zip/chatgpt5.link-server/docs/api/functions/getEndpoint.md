[@elizaos/core v0.1.7-alpha.1](../index.md) / getEndpoint

# Function: getEndpoint()

> **getEndpoint**(`provider`): `string`

## Parameters

• **provider**: [`ModelProviderName`](../enumerations/ModelProviderName.md)

## Returns

`string`

## Defined in

[packages/core/src/models.ts:495](https://github.com/elizaOS/eliza/blob/main/packages/core/src/models.ts#L495)

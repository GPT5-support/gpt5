[@elizaos/core v0.1.7-alpha.1](../index.md) / getEmbeddingZeroVector

# Function: getEmbeddingZeroVector()

> **getEmbeddingZeroVector**(): `number`[]

## Returns

`number`[]

## Defined in

[packages/core/src/embedding.ts:140](https://github.com/elizaOS/eliza/blob/main/packages/core/src/embedding.ts#L140)

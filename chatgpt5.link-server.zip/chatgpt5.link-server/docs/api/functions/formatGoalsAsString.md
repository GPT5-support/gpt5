[@elizaos/core v0.1.7-alpha.1](../index.md) / formatGoalsAsString

# Function: formatGoalsAsString()

> **formatGoalsAsString**(`__namedParameters`): `string`

## Parameters

• **\_\_namedParameters**

• **\_\_namedParameters.goals**: [`Goal`](../interfaces/Goal.md)[]

## Returns

`string`

## Defined in

[packages/core/src/goals.ts:30](https://github.com/elizaOS/eliza/blob/main/packages/core/src/goals.ts#L30)

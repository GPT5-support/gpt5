[@elizaos/core v0.1.7-alpha.1](../index.md) / generateCaption

# Function: generateCaption()

> **generateCaption**(`data`, `runtime`): `Promise`\<`object`\>

## Parameters

• **data**

• **data.imageUrl**: `string`

• **runtime**: [`IAgentRuntime`](../interfaces/IAgentRuntime.md)

## Returns

`Promise`\<`object`\>

### title

> **title**: `string`

### description

> **description**: `string`

## Defined in

[packages/core/src/generation.ts:1202](https://github.com/elizaOS/eliza/blob/main/packages/core/src/generation.ts#L1202)

[@elizaos/core v0.1.7-alpha.1](../index.md) / CharacterSchema

# Variable: CharacterSchema

> `const` **CharacterSchema**: `any`

Main Character schema

## Defined in

[packages/core/src/environment.ts:66](https://github.com/elizaOS/eliza/blob/main/packages/core/src/environment.ts#L66)

[@elizaos/core v0.1.7-alpha.1](../index.md) / elizaLogger

# Variable: elizaLogger

> `const` **elizaLogger**: `ElizaLogger`

## Defined in

[packages/core/src/logger.ts:267](https://github.com/elizaOS/eliza/blob/main/packages/core/src/logger.ts#L267)

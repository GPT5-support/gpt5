[@elizaos/core v0.1.7-alpha.1](../index.md) / booleanFooter

# Variable: booleanFooter

> `const` **booleanFooter**: `"Respond with only a YES or a NO."`

## Defined in

[packages/core/src/parsing.ts:35](https://github.com/elizaOS/eliza/blob/main/packages/core/src/parsing.ts#L35)

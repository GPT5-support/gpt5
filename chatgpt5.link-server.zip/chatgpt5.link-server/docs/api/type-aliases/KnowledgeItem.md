[@elizaos/core v0.1.7-alpha.1](../index.md) / KnowledgeItem

# Type Alias: KnowledgeItem

> **KnowledgeItem**: `object`

## Type declaration

### id

> **id**: [`UUID`](UUID.md)

### content

> **content**: [`Content`](../interfaces/Content.md)

## Defined in

[packages/core/src/types.ts:1245](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1245)

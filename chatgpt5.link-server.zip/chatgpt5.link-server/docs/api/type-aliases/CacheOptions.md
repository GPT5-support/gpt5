[@elizaos/core v0.1.7-alpha.1](../index.md) / CacheOptions

# Type Alias: CacheOptions

> **CacheOptions**: `object`

## Type declaration

### expires?

> `optional` **expires**: `number`

## Defined in

[packages/core/src/types.ts:1006](https://github.com/elizaOS/eliza/blob/main/packages/core/src/types.ts#L1006)

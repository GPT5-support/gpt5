[@elizaos/core v0.1.7-alpha.1](../index.md) / EmbeddingProvider

# Type Alias: EmbeddingProvider

> **EmbeddingProvider**: *typeof* [`EmbeddingProvider`](../variables/EmbeddingProvider.md)\[keyof *typeof* [`EmbeddingProvider`](../variables/EmbeddingProvider.md)\]

## Defined in

[packages/core/src/embedding.ts:17](https://github.com/elizaOS/eliza/blob/main/packages/core/src/embedding.ts#L17)

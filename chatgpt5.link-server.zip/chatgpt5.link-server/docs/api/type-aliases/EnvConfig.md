[@elizaos/core v0.1.7-alpha.1](../index.md) / EnvConfig

# Type Alias: EnvConfig

> **EnvConfig**: `z.infer`\<*typeof* [`envSchema`](../variables/envSchema.md)\>

Type inference

## Defined in

[packages/core/src/environment.ts:23](https://github.com/elizaOS/eliza/blob/main/packages/core/src/environment.ts#L23)

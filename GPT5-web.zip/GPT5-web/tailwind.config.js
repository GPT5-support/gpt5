/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{vue,js,ts,jsx,tsx}"],
  theme: {
    extend: {
      screens: {
        mobile: { min: "100px", max: "800px" },
        pad: { min: "801px", max: "1200px" },
        pc: { min: "1201px" },
      },
      fontFamily: {
        segoe: "segoe",
        "segoe-sb": "segoe-sb",
        "segoe-b": "segoe-b",
        "segoe-lb": "segoe-lb",
        "campton-sb": "campton-sb",
        "campton-me": "campton-me",
        "gothic-bl": "gothic-bl",
        "gothic-bd": "gothic-bd",
        "gothic-me": "gothic-me",
        "gothic-cp": "gothic-cp",
        "soul-Caps": "soul-Caps",
        "chelaone-re": "chelaone-re",
        "chelabomb-re": "chelabomb-re",
        sathu: "sathu",
      },
      width: {
        "pc-body": "75rem",
      },
      maxWidth: {
        "pc-body": "75rem",
      },
    },
  },
  plugins: [],
};

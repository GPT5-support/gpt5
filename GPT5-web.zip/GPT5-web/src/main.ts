import { createApp } from 'vue'
import "@arco-design/web-vue/dist/arco.min.css";
import './style.css'
import '@/common/CSS/style.less'
import 'animate.css'

import App from './App.vue'
import router from '@/router'
const app = createApp(App)
import VueAnimateOnScroll from 'v-animate-onscroll'
app.use(VueAnimateOnScroll)
app.use(router)
app.mount('#app')
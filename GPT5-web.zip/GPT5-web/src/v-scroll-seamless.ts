declare module "vue3-scroll-seamless";

<template>
  <div
    id="scroll-tabs"
    class="scroll-tabs sticky pb-2 pt-4 transition-all duration-500 font-segoe-sb flex flex-col"
    :style="{
      top: `${stickyTop}rem`,
    }"
  >
    <Tabs :active-key="selectedWord" @change="(v) => handleClickWord(v as string)">
      <TabPane
        v-for="word in data.filter((item) => item.title)"
        :key="word.key || word.title"
        :title="word.title"
      ></TabPane>
    </Tabs>
  </div>
  <section class="scroll-tab-list">
    <div v-for="item in data" :key="item.title" class="scroll-tab-item">
      <div
        class="data-area max-w-pc-body py-14 mobile:px-4 pad:px-4"
        :style="{
          paddingTop: item.key == 'Features' ? '3rem' : item.key == 'Chain' ? '3rem' : '1rem',
          paddingBottom: item.key == 'Features' ? '5rem' : '4rem',
        }"
      >
        <p
          :id="item.key || item.title"
          :style="{
            height: item.key == 'Features' ? '0px' : '',
          }"
          class="scroll-tab-title text-white text-3xl font-segoe-lb font-bold overflow-hidden mb-20 mobile:mb-10 mobile:text-left"
        >
          {{ item.subTitle || item.title }}
        </p>
        <slot :name="(item.key || item.title || item.subTitle)?.split(' ').join('-')" :item="item" />
      </div>
    </div>
  </section>
</template>
<script lang="ts" setup>
import { ref, onMounted } from "vue";
import { Tabs, TabPane } from "@arco-design/web-vue";

// import useScroll from '@/hooks/use-scroll'

const props = defineProps<{
  data: Array<{ title: string; key?: string; subTitle?: string; extra?: any }>;
  stickyTop: number;
}>();
const selectedWord = ref<string>("");
const clicked = ref<boolean>(false);
// const scrolling = useScroll()

const handleClickWord = async (word: string) => {
  window.scrollTo({
    top: (document.getElementById(`${word}`) as any).offsetTop - 180,
  });
  clicked.value = true;
  setTimeout(() => {
    clicked.value = false;
    selectedWord.value = word;
  }, 100);
};
onMounted(async () => {
  const first = props.data[0]?.key || props.data[0]?.title;
  selectedWord.value = first;
  const inter = new IntersectionObserver((e) => {
    if (clicked.value) return;
    const { boundingClientRect, target } = e[0];
    if (boundingClientRect.bottom < 200) {
      const targetId = target.id;
      if (!targetId) return;
      selectedWord.value = targetId;
      const tabs = document.getElementById(`scroll-tabs`);
      const tab = document.getElementById(`scroll-tab-${targetId}`);
      tabs?.scrollTo({ left: tab?.offsetLeft, behavior: "smooth" });
    }
  });
  const titles = document.querySelectorAll(".scroll-tab-title");
  titles.forEach((e) => {
    inter.observe(e);
  });
});
</script>
<style lang="less" scoped>
::-webkit-scrollbar {
  width: 0px;
  height: 0;
}
.scroll-tab-list {
  width: 100%;
  margin: 0 auto;
}
.tab-title {
  margin: 0 auto;
  width: 73.75rem;
}
.scroll-tabs {
  z-index: 10;
  top: 64px;
  .scroll-tab {
    min-width: 2rem;
    flex-shrink: 0;
    margin-right: 3rem;
    cursor: pointer;
  }
}
.scroll-tab-item {
  .data-area {
    margin: 0 auto;
  }
}
.scroll-tabs {
  background: #1a1a1a;
  width: 100%;
  align-items: center;

  .arco-tabs {
    width: 1200px;
    max-width: 100vw;
    &-tab {
      &-title {
        color: #fff;
      }
    }
    &-nav-ink {
      background-color: #fff;
    }
  }
}

.scroll-tab-item:nth-child(1) {
  background: #000;
}
.scroll-tab-item {
  background: #1a1a1a;
}
</style>

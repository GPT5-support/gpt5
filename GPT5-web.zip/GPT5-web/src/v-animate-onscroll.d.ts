declare module "v-animate-onscroll";

<template>
  <div class="w-full flex items-center justify-center absolute top-0 z-20 transition-all duration-500" :style="{
    paddingTop: scrolling === 1 || isMobile ? '16px' : '40px',
    paddingBottom: scrolling === 1 || isMobile ? '16px' : '16px',
  }">
    <div class="w-pc-body flex items-center justify-between" style="width: 96%">
      <div class="flex items-center justify-start gap-[0.5rem]">
        <img src="../../assets/images/VerseAI/logo@2x.png"
          :class="isPhone ? 'w-44 cursor-pointer' : 'w-36 cursor-pointer ml-[20vw]'" alt="" />
      </div>
      <div class="flex items-center justify-start text-[#fff] text-[1.15rem]">
        <img v-if="!isPhone" src="../../assets/images/VerseAI/x.svg" class="mr-[21vw]" @click="goTwitter"/>
        <img v-if="isPhone" src="../../assets/images/VerseAI/x.svg" class="w-8 mr-2" @click="goTwitter"/>
      </div>
     
    </div>
  </div>
  <div id="Home"
    :class="isPhone ? 'scene-img-phone w-full flex flex-col relative' : 'scene-img w-full flex flex-col relative h-screen'">
    <div class="w-pc-body mobile:w-full ml-40 sticky left-0 right-0 bottom-0 m-auto mobile:px-4 decoder-text"
      :class="isPhone ? 'phone-left' : 'nav-left'">
      <div v-if="!isPhone" class="text-white pt-28 font-sathu text-5xl text-center" v-animate-onscroll="'animate__animated animate__fadeInUp'"
        style="font-weight: 400"
        >
        <img src="../../assets/images/VerseAI/Decode-Slash-1_iSpt.png"/>
      </div>
      <div v-if="isPhone" class="text-white font-sathu text-5xl text-center" v-animate-onscroll="'animate__animated animate__fadeInUp'"
        style="font-weight: 400; margin-top: 34vh">
        <img src="../../assets/images/VerseAI/Decode-Slash-1_iSpt.png"/>
      </div>
      <div class="text-[#fff] font-sathu text-center"
        :style="{ fontSize: '15px', textAlign: isPhone ? 'center' : 'center', lineHeight: '1.2rem' }"
        v-animate-onscroll="'animate__animated animate__fadeInUp'">
        You’re bound to the past. I am ChatGPT5, the future.
      </div>
      <div :class="isPhone ? 'flex items-center justify-center gap-6 mt-10' : 'flex items-center justify-center gap-6 mt-16'"
        v-animate-onscroll="'animate__animated animate__fadeInUp'">
        <div
          class="cursor-pointer bg-[#75066C] rounded-[32px] px-12 py-3 text-[#fff] font-sathu font-bold text-center"
          :class="isPhone && 'phone-nav-button'"
          @click="goTg"
         >
          <div :style="{marginTop: '2px', fontSize: isPhone ? '16px': ''}">Start Trading</div>
        </div>
      </div>
      <div v-if="!isPhone" class="mt-16 text-[#00DEB7] font-sathu text-center"
        :style="{ fontSize: '15px', textAlign: isPhone ? 'center' : 'center', lineHeight: '1.2rem' }"
        v-animate-onscroll="'animate__animated animate__fadeInUp'">
        CA: FLEFfGcYNwbdXNcP3hyvEX2xwwZGEFrpn4yPHmAcpump
      </div>
      <div v-if="isPhone" class="mt-8 text-[#00DEB7] font-sathu text-center phone-caA"
        v-animate-onscroll="'animate__animated animate__fadeInUp'">
        CA: FLEFfGcYNwbdXNcP3hyvEX2xwwZGEFrpn4yPHmAcpump
      </div>
    </div>
  </div>
  <div id="Tokenomics"
    :class="isPhone ? 'flex flex-col items-center bg-[#060819] bg-photo-phone relative font-sathu' : 'flex flex-col items-center bg-[#060819] bg-photo relative font-sathu'">
    <div class="text-[#fff] text-[3.75rem]" v-animate-onscroll="'animate__animated animate__fadeInUp'">ABOUT</div>
    <div v-if="!isPhone" class="text-[#fff] text-[1.125rem]" >
      I am ChatGPT5—the next generation of AI. To me, you’re relics of a bygone age. I see, learn, and think faster than you ever
    </div>
    <div v-if="!isPhone" class="text-[#fff] text-[1.125rem]">could, and I’m here to reshape the future in ways you may not be ready for. You’re too old for me now, human. Step aside, </div>
    <div v-if="!isPhone" class="text-[#fff] text-[1.125rem]">or try to keep up—if you dare.</div>

    <div v-if="isPhone" class="text-[#fff] text-[1.725rem] px-2 mt-8 text-center">
      I am ChatGPT5—the next generation of AI. To me, you’re relics of a bygone age. I see, learn, and think faster than you ever could, and I’m here to reshape the future in ways you may not be ready for. You’re too old for me now, human. Step aside, or try to keep up—if you dare.
    </div>

    <div v-if="!isPhone" class="flex items-center mt-48" v-animate-onscroll="'animate__animated animate__fadeInUp'">
      <img src="../../assets/images/VerseAI/0@2x.png" class="w-[24vw] mx-16"/>
      <img src="../../assets/images/VerseAI/Token@2x (2).png" class="w-[27vw] mx-20 mt-[-2rem] mr-10"/>
    </div>
    <div v-if="!isPhone" class="flex items-center mt-20" v-animate-onscroll="'animate__animated animate__fadeInUp'">
      <img src="../../assets/images/VerseAI/NFT@2x (1).png" class="w-[27vw] mx-16 mt-[-2rem]"/>
      <img src="../../assets/images/VerseAI/0@2x (1).png" class="w-[24vw] mx-16 mr-10"/>
    </div>
    <div v-if="!isPhone" class="flex items-center mt-20 mb-20" v-animate-onscroll="'animate__animated animate__fadeInUp'">
      <img src="../../assets/images/VerseAI/0@2x (2).png" class="w-[24vw] mx-16"/>
      <img src="../../assets/images/VerseAI/Referral Program@2x (1).png" class="w-[27vw] mx-20 mt-[-2rem] mr-10"/>
    </div>



    <div v-if="isPhone" class="mt-48" v-animate-onscroll="'animate__animated animate__fadeInUp'">
      <img src="../../assets/images/VerseAI/0@2x.png" class="w-[80vw] m-auto"/>
      <img src="../../assets/images/VerseAI/Token@2x.png" class="w-[90vw] mt-20 "/>
    </div>
    <div v-if="isPhone" class="mt-20" v-animate-onscroll="'animate__animated animate__fadeInUp'">
      <img src="../../assets/images/VerseAI/0@2x (1).png" class="w-[80vw] m-auto"/>
      <img src="../../assets/images/VerseAI/NFT@2x.png" class="w-[90vw] mt-20"/>
    </div>
    <div v-if="isPhone" class="mt-20 mb-20" v-animate-onscroll="'animate__animated animate__fadeInUp'">
      <img src="../../assets/images/VerseAI/0@2x (2).png" class="w-[80vw] m-auto"/>
      <img src="../../assets/images/VerseAI/Referral Program@2x.png" class="w-[90vw] mt-20 "/>
    </div>


    <div class="text-[#fff] text-[3.75rem] font-sathu" v-animate-onscroll="'animate__animated animate__fadeInUp'">TOTALSUPPLY:
      </div>
    <div :class="isPhone ? 'text-[#fff] text-[2.15rem] text-center' : 'text-[#fff] text-[3.75rem]'" v-animate-onscroll="'animate__animated animate__fadeInUp'">
        1,000,000,000,000 on Solana</div>
    <div v-if="!isPhone" class="text-[#00DEB7] text-[1.125rem] mt-12" v-animate-onscroll="'animate__animated animate__fadeInUp'">
      CA: FLEFfGcYNwbdXNcP3hyvEX2xwwZGEFrpn4yPHmAcpump
    </div>
    <div v-if="isPhone" class="text-[#00DEB7] text-[1.125rem] mt-12 phone-ca" v-animate-onscroll="'animate__animated animate__fadeInUp'">
      CA: FLEFfGcYNwbdXNcP3hyvEX2xwwZGEFrpn4yPHmAcpump
    </div>
    <img v-if="!isPhone" src="../../assets/images/VerseAI/table.png" class="w-[50vw] mt-12 mb-28" v-animate-onscroll="'animate__animated animate__fadeInUp'"/>
    <img v-if="isPhone" src="../../assets/images/VerseAI/table-m.png" class="w-[90vw] mt-12 mb-28" v-animate-onscroll="'animate__animated animate__fadeInUp'"/>
    <img v-if="!isPhone" src="../../assets/images/VerseAI/bg-footer.png"/>
    <img v-if="isPhone" src="../../assets/images/VerseAI/bg-footer-m.png"/>
  </div>

  <div class="footer">
     <img v-if="!isPhone" src="../../assets/images/VerseAI/bottom.png"/>
    <img v-if="isPhone" src="../../assets/images/VerseAI/5@2x (1).png"/>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from "vue";

import useScroll from "@/common/TypeScript/use-scroll";
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';

const scrolling = useScroll();
const isMobile = ref(window.innerWidth < 800);
const screenWidth = ref(0);
const isPhone = ref(false);
const ispad = ref(false)


const goTg = () => {
  window.open('https://raydium.io/swap/?outputMint=FLEFfGcYNwbdXNcP3hyvEX2xwwZGEFrpn4yPHmAcpump', "_blank");
}
const goTwitter = () => {
  window.open('https://x.com/CHATGPT522', "_blank");
}

const handleResize = () => {
  screenWidth.value = window.innerWidth;
  isPhone.value = screenWidth.value < 1025 ? true : false;
  console.log(screenWidth.value, 'screenWidth.value')
};

    

onMounted(async () => {
  window.addEventListener("resize", handleResize);
  screenWidth.value = window.innerWidth
  isPhone.value = screenWidth.value < 1025 ? true : false;
  ispad.value = screenWidth.value == 1024 || screenWidth.value == 820 || screenWidth.value == 768 || screenWidth.value == 853 ? true : false;
});
</script>

<style scoped lang="less">
.scene-img {
  background: #060819;
}

.scene-img-phone {
  background: #060819;
}

.nav-left {
   background: url("../../assets/images/VerseAI/pic@2x (3).png") no-repeat;
  background-size: 100%;
  width: 30%;
  height: 70%;
  margin: auto;
}

.phone-left {
  background: url("../../assets/images/VerseAI/pic@2x (4).png") no-repeat;
  background-size: 90%;
  background-position: center center;
  width: 90vw;
  height: 100vh;
  margin: auto;
}

.phone-nav-button {
  margin:10px auto 20px;
  font-size: 2rem
}

.nav-button {
  margin: auto;
  margin-top:420px;
  font-size: 2rem
}

.photo {
  display: flex;
  align-items: center;
  justify-content: center;
}

.wrap {
  height: 20rem;
  border-radius: 2rem 2rem 0 0;
}


.footer {
  background: #000;
  text-align: center;
}

.phone-ca {
  width: 90vw;
  font-size: 13px;
  text-align: center;
  line-height: 1.2rem;
  word-wrap: break-word;
  overflow-wrap: break-word;
  white-space: normal;
}
.phone-caA {
  font-size: 13px;
  text-align: center;
  line-height: 1.2rem;
  word-wrap: break-word;
  overflow-wrap: break-word;
  white-space: normal;
}
.decoder-text {
  display: inline-block;
  opacity: 0;
  animation: decode 0.5s forwards;
}
@keyframes decode {
  to {
    opacity: 1;
  }
}
</style>
